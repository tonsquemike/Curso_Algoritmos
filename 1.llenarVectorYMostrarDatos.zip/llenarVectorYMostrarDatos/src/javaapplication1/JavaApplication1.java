/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import static javaapplication1.Funciones.Escribir;
import static javaapplication1.Funciones.Leer;

/**
 *
 * @author mike
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] vector;//la Dimesion vector sólo puede llenarse con valores enteros
        int tamanio;
        //leer un valor desde teclado
        Escribir("Ingresa el tamaño del vector");
        tamanio = Integer.parseInt(Leer());//Se lee una cadena y se transforma a entero
        
        //asignar un tamaño a la Dimensión
        vector = new int[tamanio];
             //desde  ;   hasta    ; con paso
        for (int i = 0; i < tamanio;  i=i+1) {
            //Integer.parseInt(valorEntero); --> permite cambiar el tipo
            //                               de dato de un String a un entero
            Escribir("ingresa el valor de la casilla "+i);
            vector[i] = Integer.parseInt(Leer());
            //Escribir(String.valueOf(vector[i]));//mostrar datos
            //String.valueOf()-->cambiar cualquier tipo de dato
            //                  a una cadena de texto
        }
        for (int i = 0; i < tamanio; i++) {
            //Escribir("");--> sout+TAB
            //String.valueOf(variable);--> transforma cualquier dato a un String
            Escribir("vector["+i+"]="+String.valueOf(vector[i]));
        }
        
        
        
        
        
        
        
        
    }
    
}
